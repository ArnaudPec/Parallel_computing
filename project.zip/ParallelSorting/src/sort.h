
#ifdef __cplusplus
extern "C" {
#endif


#if NB_THREADS > 0

struct chunck{
    int id;
    int * array;
    size_t size;
    int pivots[NB_THREADS-1];
    int subarray_sizes[NB_THREADS];
    int* sorted_arrays[NB_THREADS];
};

static void* qs(void* data);

#endif
// Some sort implementation
void sort(int* array, size_t size);

#ifdef __cplusplus
}
#endif
